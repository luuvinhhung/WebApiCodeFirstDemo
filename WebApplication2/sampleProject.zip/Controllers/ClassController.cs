﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using WebApplication2.DBModels;
using WebApplication2.ViewModels;

namespace WebApplication2.Controllers
{
	public class ClassController : ApiController
	{
		private SampleEntities _db;

		public ClassController()
		{
			this._db = new SampleEntities();
		}

		[HttpPost]
		public IHttpActionResult TaoLop(CreateClassModel model)
		{
			IHttpActionResult httpActionResult;
			ErrorModel errors = new ErrorModel();

			if (string.IsNullOrEmpty(model.MaLop))
			{
				errors.Add("Mã lớp là trường bắt buộc");
			}

			if (string.IsNullOrEmpty(model.TenLop))
			{
				errors.Add("Tên lớp là trường bắt buộc");
			}

			if (errors.Errors.Count == 0)
			{
				Lop lop = new Lop();
				lop.malop = model.MaLop;
				lop.tenlop = model.TenLop;

				lop = _db.Lops.Add(lop);

				this._db.SaveChanges();

				ClassModel viewModel = new ClassModel(lop);

				httpActionResult = Ok(viewModel);
			}
			else
			{
				httpActionResult = Ok(errors);
			}

			return httpActionResult;
		}

		[HttpPut]
		public IHttpActionResult CapNhatLop(UpdateClassModel model)
		{
			IHttpActionResult httpActionResult;
			ErrorModel errors = new ErrorModel();

			Lop lop = this._db.Lops.FirstOrDefault(x => x.id == model.Id);

			if (lop == null)
			{
				errors.Add("Không tìm thấy lớp");

				httpActionResult = Ok(errors);
			}
			else
			{
				lop.malop = model.MaLop ?? model.MaLop;
				lop.tenlop = model.TenLop ?? model.TenLop;

				this._db.Entry(lop).State = System.Data.Entity.EntityState.Modified;

				this._db.SaveChanges();

				httpActionResult = Ok(new ClassModel(lop));
			}

			return httpActionResult;
		}

		[HttpGet]
		public IHttpActionResult GetAll()
		{
			var listLops = this._db.Lops.Select(x => new ClassModel()
			{
				MaLop = x.malop,
				TenLop = x.tenlop,
				Id  = x.id
			});

			return Ok(listLops);
		}

		[HttpGet]
		public IHttpActionResult GetById(int id)
		{
			IHttpActionResult httpActionResult; 
			var lop = _db.Lops.FirstOrDefault(x => x.id == id);

			if (lop == null)
			{
				ErrorModel errors = new ErrorModel();
				errors.Add("Không tìm thấy lớp");

				httpActionResult = Ok(errors);
			}
			else
			{
				httpActionResult = Ok(new ClassModel(lop));
			}

			return httpActionResult;
		} 
	}
}