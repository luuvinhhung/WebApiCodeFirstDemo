﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication2.DBModels;

namespace WebApplication2.ViewModels
{
	public class ClassModel
	{
		public string MaLop { get; set; }
		public string TenLop { get; set; }
		public int Id { get; set; }

		public ClassModel() { }
		public ClassModel(Lop lop)
		{
			this.MaLop = lop.malop;
			this.TenLop = lop.tenlop;
			this.Id = lop.id;
		}
	}

	public class CreateClassModel
	{
		public string MaLop { get; set; }
		public string TenLop { get; set; }
	}

	public class UpdateClassModel : CreateClassModel
	{
		public int Id { get; set; }
	}
}